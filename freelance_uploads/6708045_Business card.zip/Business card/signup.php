
<?php
          
          include 'db.php';
          if(isset($_REQUEST["btnsignup"])){
              $signup_email=$_REQUEST["signupmail"];
              $signup_pass=$_REQUEST["signuppass"];
              $signup_user=$_REQUEST["txtusername"];
              $flag=0;
              $qry1="SELECT user_email, username FROM user_signup_details";
              $result=mysqli_query($con,$qry1);
              while($row=mysqli_fetch_array($result)){
                if($row["user_email"]==$signup_email){
                  echo "
                  <div class='container-fluid'>
                    <div class='row'>
                    <div class='col-7'></div>
                    <div class='col'>
                    <p class='text-danger mt-3 text-center'>Email Already exists , please log in</p>
                    </div>
                    <div class='col'></div>
                    </div>
                  </div>
                  
                  ";
                  $flag=1;
                  exit();
                }
                if($row["username"]==$signup_user){
                  echo "
                  <div class='container-fluid'>
                    <div class='row'>
                    <div class='col-7'></div>
                    <div class='col'>
                    <p class='text-danger mt-3 text-center'>Username Already exists , please enter another name</p>
                    </div>
                    <div class='col'></div>
                    </div>
                  </div>
                  
                  ";
                  $flag=1;
                  exit();
                }

              }
              if($flag==0){
                include 'db.php';
                  $qry2="INSERT INTO user_signup_details(username,user_email,user_password) VALUES('$signup_user','$signup_email','$signup_pass')";
                  mysqli_query($con,$qry2);
               //    $qry3="SELECT user_id FROM user_signup_details WHERE user_email='$signup_email'";
               //    $result_middle=mysqli_query($con,$qry3);
               //    $row_middle=mysqli_fetch_array($result_middle);
               //    $row_middle_uid=$row_middle["user_id"];
                  header("Location: login.php");

              }
              
              
          }

          ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <script src="https://kit.fontawesome.com/467d4a99f6.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
  </head>
  <body>

    <div class="container-fluid">
        <div class="row pt-5">
            <div class="col-1"></div>
            <div class="col">LOGO</div>
            <div class="col-8"></div>
            <div class="col" ><a href="login.php" class="btn all-bgcolor rounded-pill text-white fw-bold">SIGN IN</a></div>
            <div class="col-1"></div>
            </div>
        
    </div>

    <div class="container-fluid d-none d-md-block">
        <div class="row ">
            <div class="col-1"></div>
            <div class="col-6">
                <img src="images/login image.jpeg" class="img-fluid" alt="" >
            </div>
            <div class="col pt-5 mt-4">
                <span class="fs-3 fw-bold">REGISTER NOW!</span>
                <p class="fs-4">Signup to continue</p>
                
            <form action="signup.php" method="post">


                <div class="input-group mb-3 pt-4">
                    <span class="input-group-text bg-white" style="border-right: 0px; border-top-left-radius:50%; border-bottom-left-radius:50%;" id="basic-addon1"><i class="fa-solid fa-user"></i></span>
                    <input type="text" class="form-control " placeholder="Enter your E-mail" aria-label="Email" name="signupmail" aria-describedby="basic-addon1" style="border-left: 0px; border-top-right-radius:18px; border-bottom-right-radius:18px;">
                </div>

                <div class="input-group mb-3 pt-2">
                    <span class="input-group-text bg-white" style="border-right: 0px; border-top-left-radius:50%; border-bottom-left-radius:50%;" id="basic-addon2"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" class="form-control " placeholder="Set your Password" aria-label="Password" name="signuppass" id="setpass" aria-describedby="basic-addon2" style="border-left: 0px; border-top-right-radius:18px; border-bottom-right-radius:18px;">
                </div>

                <div class="input-group mb-3 pt-2">
                    <span class="input-group-text bg-white" style="border-right: 0px; border-top-left-radius:50%; border-bottom-left-radius:50%;" id="basic-addon2"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" class="form-control " placeholder="Confirm your Password" aria-label="Password"  id="confirmpass" aria-describedby="basic-addon2" style="border-left: 0px; border-top-right-radius:18px; border-bottom-right-radius:18px;">
                </div>

                <div class="row pt-3">
                    <div class="col">
                        <input type="submit" class="btn text-white all-bgcolor rounded-pill fw-bold" name="btnsignup" value="SIGN UP">
                    </div>
                    <div class="col">
                       <span>Already a Member?<a href="login.php" class="forgetpass all-color" style="text-decoration:underline;"> Sign In </a></span> 
                    </div>
                </div>

                <div class="row pt-4">
                    <div class="col">
                        <span class="pe-4">SignUp With :</span>
                        <a href="#" class="all-color pe-3"><i class="fa-brands fa-google fs-3"></i></a>
                        <a href="#" class="all-color"><i class="fa-brands fa-facebook fs-3"></i></a>
                    </div>
                </div>
            </div>


        </form>


            <div class="col-1"></div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html>